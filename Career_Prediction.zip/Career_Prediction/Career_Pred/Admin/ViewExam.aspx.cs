﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_ViewExam : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            fillGridView();
    }

    protected void gvExam_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string e_id = e.CommandArgument.ToString();

        if (e.CommandName == "EditTable")
            Response.Redirect("AddExam.aspx" + "?action=edit&id=" +e_id);
        else if (e.CommandName == "DeleteTable")
            deleteRow(e_id);
    }



    private void fillGridView()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from exam_master", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if(dt.Rows.Count > 0)
            {
                gvExam.DataSource = dt;
                gvExam.DataBind();
            }
            else
            {
                gvExam.DataSource = null;
                gvExam.DataBind();
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }

    private void deleteRow(string e_id)
    {
        try
        {
            con = new SqlConnection(constr);
            if (con.State != ConnectionState.Open)
                con.Open();
            cmd = new SqlCommand("delete from exam_master where e_id=@id", con);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(e_id));
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
                fillGridView();
            else
                Response.Write("<script>alert('Something went wrong')</script>");

        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
}