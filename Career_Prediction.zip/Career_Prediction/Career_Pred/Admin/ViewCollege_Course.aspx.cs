﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_ViewCollege_Course : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            fillGridView();
    }

    private void fillGridView()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select c.c_name,cm.course_name,ccm.cc_id,ccm.course_type,ccm.course_status,ccm.course_acdr,ccm.course_year,ccm.course_intake from college_course_master ccm inner join course_master cm on ccm.course_id = cm.course_id inner join college_master c on ccm.college_id = c.c_id ", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                gvCourse.DataSource = dt;
                gvCourse.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void gvCourse_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string cc_id = e.CommandArgument.ToString();

        if (e.CommandName == "EditTable")
            Response.Redirect("AddCollege_Course.aspx" + "?action=edit&id=" + cc_id);
        else if (e.CommandName == "DeleteTable")
            deleteRow(cc_id);
    }

    private void deleteRow(string cc_id)
    {
        try
        {
            con = new SqlConnection(constr);
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd = new SqlCommand("delete from college_course_master where cc_id=@id", con);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(cc_id));
            int result = (int)cmd.ExecuteNonQuery();
            if (result == 1)
                fillGridView();
            con.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}