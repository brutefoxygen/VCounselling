﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_ViewCollege : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            fillGridView();
    }

    private void fillGridView()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select c.*,CASE WHEN c.c_region_type = 1 THEN 'Rural' ELSE 'Urban' END as region_type,a.area_name from college_master c inner join area_master a on c.c_area = a.area_id", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if(dt.Rows.Count > 0)
            {
                gvCollege.DataSource = dt;
                gvCollege.DataBind();
            }
            else
            {
                gvCollege.DataSource = null;
                gvCollege.DataBind();
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
    protected void gvCollege_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string c_id = e.CommandArgument.ToString();

        if (e.CommandName == "EditTable")
            Response.Redirect("AddCollege.aspx" + "?action=edit&id=" + c_id);
        else if (e.CommandName == "DeleteTable")
            deleteRow(c_id);
    }

    private void deleteRow(string c_id)
    {
        try
        {
            con = new SqlConnection(constr);
            if (con.State != ConnectionState.Open)
                con.Open();


            cmd = new SqlCommand("delete from college_course_master where college_id=@id", con);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(c_id));
            cmd.ExecuteNonQuery();


            cmd = new SqlCommand("delete from college_master where c_id=@id", con);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(c_id));
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
                fillGridView();
            else
                Response.Write("<script>alert('Something went wrong')</script>");

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}