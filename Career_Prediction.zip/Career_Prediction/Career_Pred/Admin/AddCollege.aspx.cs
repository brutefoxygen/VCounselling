﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddCollege : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    string operation, c_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillDropDown();
        }

        operation = Request.QueryString["action"].ToString();
        if (operation.Trim() == "edit")
        {
            c_id = Request.QueryString["id"].ToString();
            if (!IsPostBack)
                getCollegeDetails(c_id);
        }
    }



    protected void btn_Click(object sender, EventArgs e)
    {
        try
        {
            
                con = new SqlConnection(constr);
                if (con.State != ConnectionState.Open)
                    con.Open();

                if (operation.Trim() == "edit")
                    cmd = new SqlCommand("update college_master set c_name=@name,c_area=@area,c_region_type=@type,c_address=@addr,c_district=@dist,c_taluka=@taluka,c_pincode=@pin,c_std_code=@std,c_year=@year,c_web=@web,c_email=@email,c_contact=@contact,c_rail=@rail,c_rail_km=@rkm,c_bus=@bus,c_bus_km=@bkm,c_air=@air,c_air_km=@akm where c_id=@c_id", con);
                else
                    cmd = new SqlCommand("insert into college_master output INSERTED.c_id values (@name,@area,@type,@addr,@dist,@taluka,@pin,@std,@year,@web,@email,@contact,@rail,@rkm,@bus,@bkm,@air,@akm)", con);

                cmd.Parameters.AddWithValue("@c_id", Convert.ToInt32(c_id));
                cmd.Parameters.AddWithValue("@name", txtName.Text.ToString());
                cmd.Parameters.AddWithValue("@area", ddArea.SelectedValue);
                cmd.Parameters.AddWithValue("@type", ddRegType.SelectedValue);
                cmd.Parameters.AddWithValue("@addr", txtAddr.Text.ToString());
                cmd.Parameters.AddWithValue("@dist", txtDist.Text.ToString());
                cmd.Parameters.AddWithValue("@taluka", txtTaluka.Text.ToString());
                cmd.Parameters.AddWithValue("@pin", Convert.ToInt32(txtPin.Text.ToString()));
                cmd.Parameters.AddWithValue("@std", Convert.ToInt32(txtCode.Text.ToString()));
                cmd.Parameters.AddWithValue("@year", Convert.ToInt32(txtYear.Text.ToString()));
                cmd.Parameters.AddWithValue("@web", txtWeb.Text.ToString());
                cmd.Parameters.AddWithValue("@email", txtEmail.Text.ToString());
                cmd.Parameters.AddWithValue("@contact", txtContact.Text.ToString());
                cmd.Parameters.AddWithValue("@rail", txtRail.Text.ToString());
                cmd.Parameters.AddWithValue("@rkm", Convert.ToInt32(txtRKm.Text.ToString()));
                cmd.Parameters.AddWithValue("@bus", txtBus.Text.ToString());
                cmd.Parameters.AddWithValue("@bkm", Convert.ToInt32(txtBKm.Text.ToString()));
                cmd.Parameters.AddWithValue("@air", txtAir.Text.ToString());
                cmd.Parameters.AddWithValue("@akm", Convert.ToInt32(txtAKm.Text.ToString()));
                cmd.ExecuteNonQuery();

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void fillDropDown()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from area_master", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                ddArea.DataTextField = "area_name";
                ddArea.DataValueField = "area_id";
                ddArea.DataSource = dt;
                ddArea.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void getCollegeDetails(string c_id)
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from college_master where c_id=@c_id", con);
            cmd.Parameters.AddWithValue("@c_id", Convert.ToInt32(c_id));
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if(dt.Rows.Count > 0)
            {
                txtName.Text = dt.Rows[0]["c_name"].ToString();
                ddArea.SelectedValue = dt.Rows[0]["c_area"].ToString();
                ddRegType.SelectedValue = dt.Rows[0]["c_region_type"].ToString();
                txtAddr.Text = dt.Rows[0]["c_address"].ToString();
                txtDist.Text = dt.Rows[0]["c_district"].ToString();
                txtTaluka.Text = dt.Rows[0]["c_taluka"].ToString();
                txtPin.Text = dt.Rows[0]["c_pincode"].ToString();
                txtCode.Text = dt.Rows[0]["c_std_code"].ToString();
                txtYear.Text = dt.Rows[0]["c_year"].ToString();
                txtWeb.Text = dt.Rows[0]["c_web"].ToString();
                txtEmail.Text = dt.Rows[0]["c_email"].ToString();
                txtContact.Text = dt.Rows[0]["c_contact"].ToString();
                txtRail.Text = dt.Rows[0]["c_rail"].ToString();
                txtRKm.Text = dt.Rows[0]["c_rail_km"].ToString();
                txtBus.Text = dt.Rows[0]["c_bus"].ToString();
                txtBKm.Text = dt.Rows[0]["c_bus_km"].ToString();
                txtAir.Text = dt.Rows[0]["c_air"].ToString();
                txtAKm.Text = dt.Rows[0]["c_air_km"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

   


}