﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Manage_Course : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            fillGridView();
    }
    protected void gvCourse_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string c_id = e.CommandArgument.ToString();

        if (e.CommandName == "EditTable")
            Response.Redirect("AddCourse.aspx" + "?action=edit&id=" + c_id);
        else if (e.CommandName == "DeleteTable")
            deleteRow(c_id);

    }

    void fillGridView()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from course_master", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                gvCourse.DataSource = dt;
                gvCourse.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    void deleteRow(string id)
    {
        try
        {
            con = new SqlConnection(constr);
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd = new SqlCommand("delete from course_master where course_id=@id", con);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(id));
            int result = (int)cmd.ExecuteNonQuery();
            if (result == 1)
                fillGridView();
            con.Close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

}