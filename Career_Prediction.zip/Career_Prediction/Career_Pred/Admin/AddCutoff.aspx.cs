﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddCutoff : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    string operation;
    string co_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        operation = Request.QueryString["action"].ToString();
        if (operation.Trim() == "edit")
            co_id = Request.QueryString["id"].ToString();

        if (!IsPostBack)
        {
            fillCollegeDropdown();
            if (operation.Trim() == "edit")
            {
               getCutoffDetails(co_id);
            }
        }
    }

    private void getCutoffDetails(string co_id)
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from college_cutoff_master where co_id=@co_id", con);
            cmd.Parameters.AddWithValue("@co_id", Convert.ToInt32(co_id));
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if(dt.Rows.Count >0)
            {
                btnAdd.Text = "Edit";
                ddCollege.SelectedValue = dt.Rows[0]["c_id"].ToString();
                ddCollege.Enabled = false;
                txtGeneral.Text = dt.Rows[0]["jee_general"].ToString();
                txtSc.Text = dt.Rows[0]["jee_sc"].ToString();
                txtSt.Text = dt.Rows[0]["jee_st"].ToString();
                txtObc.Text = dt.Rows[0]["jee_obc"].ToString();
                txtGeneralG.Text = dt.Rows[0]["gate_general"].ToString();
                txtScG.Text = dt.Rows[0]["gate_sc"].ToString();
                txtStG.Text = dt.Rows[0]["gate_st"].ToString();
                txtObcG.Text = dt.Rows[0]["gate_obc"].ToString();
            }
            else
            {
                ddCollege.DataSource = null;
                ddCollege.DataBind();
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(constr);
            if (con.State != ConnectionState.Open)
                con.Open();

            if (operation.Trim() == "edit")
                cmd = new SqlCommand("update college_cutoff_master set jee_general=@gen,jee_sc=@sc,jee_st=@st,jee_obc=@obc,gate_general=@ggen,gate_sc=@gsc,gate_st=@gst,gate_obc=@gobc where co_id=@id", con);
            else
                cmd = new SqlCommand("insert into college_cutoff_master values (@c_id,@gen,@sc,@st,@obc,@ggen,@gsc,@gst,@gobc)", con);

            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(co_id));
            cmd.Parameters.AddWithValue("@c_id", ddCollege.SelectedValue);
            cmd.Parameters.AddWithValue("@gen", txtGeneral.Text);
            cmd.Parameters.AddWithValue("@sc", txtSc.Text);
            cmd.Parameters.AddWithValue("@st", txtSt.Text);
            cmd.Parameters.AddWithValue("@obc", txtObc.Text);
            cmd.Parameters.AddWithValue("@ggen", txtGeneralG.Text);
            cmd.Parameters.AddWithValue("@gsc", txtScG.Text);
            cmd.Parameters.AddWithValue("@gst", txtStG.Text);
            cmd.Parameters.AddWithValue("@gobc", txtObcG.Text);

            int result = cmd.ExecuteNonQuery();
            if (result == 1)
                Response.Redirect("ViewCutoff.aspx");
            else
                Response.Write("<script>alert('Something went wrong')</script>");
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }

    private void fillCollegeDropdown()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select c_id,c_name from college_master where c_id NOT IN (select c_id from college_cutoff_master)", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                ddCollege.DataTextField = "c_name";
                ddCollege.DataValueField = "c_id";
                ddCollege.DataSource = dt;
                ddCollege.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

   
}
