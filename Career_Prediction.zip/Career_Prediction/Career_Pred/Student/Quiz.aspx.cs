﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_Quiz : System.Web.UI.Page
{
    string s_id;
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    string ans;
    // string [] corrAns = new string[10];
    static List<string> strList;
    string cor = "";
    int correct = 0;
    int wrong = 0;
    bool flag = false;
    int c_id;
    int rbCheckCount;
    string s_email;
    string c_name = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["s_id"] == null)
            Response.Redirect("../Login.aspx");

        s_id = Session["s_id"].ToString();

        c_id = Convert.ToInt32(Request.QueryString["id"].ToString());
        if (!IsPostBack)
            loadQues(c_id);

        strList = new List<string>();
    }

    private void loadQues(int c_id)
    {
        try
        {
            // rbOpt.Items.Clear();
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select top 10 q.q_id,q.q_ques,q.q_opt1,q.q_opt2,q.q_opt3,q.q_opt4,q.q_ans,c.course_name from question_master q inner join course_master c on q.c_id = c.course_id where q.c_id =@id ORDER BY NEWID()", con);
            cmd.Parameters.AddWithValue("@id", c_id);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count >= 10)
            {
                dlQuiz.DataSource = dt;
                dlQuiz.DataBind();
            }
            else
            {
                Response.Write("<script>alert('Quiz not available')</script>");
                Response.Redirect("Home.aspx");
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void btn_Click(object sender, EventArgs e)
    {
        string str = "";

        foreach (RepeaterItem item in dlQuiz.Items)
        {
            RadioButton rb = item.FindControl("rdOption1") as RadioButton;
            RadioButton rb2 = item.FindControl("rdOption2") as RadioButton;
            RadioButton rb3 = item.FindControl("rdOption3") as RadioButton;
            RadioButton rb4 = item.FindControl("rdOption4") as RadioButton;

            // if (rb.Text == " ")
            //  {
            if (rb.Checked == false && rb2.Checked == false && rb3.Checked == false && rb4.Checked == false)
            {
                lblMsg.Visible = true;
            }
            else
            {
                flag = true;
                if (rb != null && rb.Checked)
                {
                    str += rb.Text + ",";
                    rbCheckCount++;
                    // Response.Write(rb.Text);
                }
                if (rb2 != null && rb2.Checked)
                {
                    str += rb2.Text + ",";
                    rbCheckCount++;
                    //Response.Write(rb1.Text);
                }
                if (rb3 != null && rb3.Checked)
                {
                    str += rb3.Text + ",";
                    rbCheckCount++;
                    // Response.Write(rb.Text);
                }
                if (rb4 != null && rb4.Checked)
                {
                    str += rb4.Text + ",";
                    rbCheckCount++;
                    //Response.Write(rb1.Text);
                }
            }
        }

        foreach (RepeaterItem item in dlQuiz.Items)
        {
            Label lbl = item.FindControl("lblAns") as Label;
            Label lblC = item.FindControl("lblCname") as Label;
            c_name += lblC.Text + ",";
            cor += lbl.Text + ",";
        }

        string[] ans = str.Split(',');
        string[] corrAns = cor.Split(',');
        string[] course = c_name.Split(',');

        for (int i = 0; i < ans.Length - 1; i++)
        {
            if (ans[i] == corrAns[i])
                correct++;
            else
                wrong++;
        }


        int totalQues = ans.Length - 1;
        int total = correct + wrong;
        string status;
        if (wrong > 4)
            status = "Fail";
        else
            status = "Pass";


        lblTotal.Text = totalQues.ToString();
        lblCorrect.Text = correct.ToString();
        lblWrong.Text = wrong.ToString();
        lblStatus.Text = status;
        lblCourse.Text = course[0].ToString();
        if (status == "Pass")
        {
            lblRecMsg.Text = "You can choose " + course[0] + " as your career path";
        }

        if (rbCheckCount == 10)
            divDonate.Visible = true;

     }


    protected void btnClose_Click(object sender, EventArgs e)
    {
        divDonate.Visible = false;
        Response.Redirect("Home.aspx");
    }
    protected void dlQuiz_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        //if (e.Item.ItemType == ListItemType.Item)
        //{
        //    RadioButton RadioButtonList1 = (RadioButton)e.Item.FindControl("rb");
        //    //Get questionID here
        //    string QuestionID = DataBinder.Eval(e.Item.DataItem, "q_opt1").ToString();
        //    //pass Question ID to your DB and get all available options for the question
        //    //Bind the RadiobUttonList here
        //}
    }
}