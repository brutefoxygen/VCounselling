﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_CompareCollege : System.Web.UI.Page
{
    
    int c1_id,c2_id;
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["s_id"] == null)
            Response.Redirect("../Login.aspx");

        c1_id = Convert.ToInt32(Request.QueryString["c1_id"].ToString());
        c2_id = Convert.ToInt32(Request.QueryString["c2_id"].ToString());
        if (!IsPostBack)
            getCollegeDetails(c1_id,c2_id);
    }

    private void getCollegeDetails(int c1_id,int c2_id)
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select c.*,area_name,cm.course_name,ccm.course_type,ccm.course_status,ccm.course_acdr,ccm.course_year,COALESCE(ccm.course_intake,0) as course_intake,CASE WHEN c.c_area = 1 THEN 'Urban' ELSE 'RURAL' end as c_area_type from college_course_master ccm right join college_master c on ccm.college_id = c.c_id inner join area_master a on c.c_area = a.area_id left join course_master cm on ccm.course_id = cm.course_id where c.c_id = @c1_id", con);
            cmd.Parameters.AddWithValue("@c1_id", c1_id);
            cmd.Parameters.AddWithValue("@c2_id", c2_id);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                lblName.Text = dt.Rows[0]["c_name"].ToString();
                lblRegion.Text = dt.Rows[0]["area_name"].ToString();
                lblType.Text = dt.Rows[0]["c_area_type"].ToString();
                lblAddress.Text = dt.Rows[0]["c_address"].ToString();
                lblDistrict.Text = dt.Rows[0]["c_district"].ToString();
                lblTaluka.Text = dt.Rows[0]["c_taluka"].ToString();
                lblPin.Text = dt.Rows[0]["c_pincode"].ToString();
                lblStd.Text = dt.Rows[0]["c_std_code"].ToString();
                lblYear.Text = dt.Rows[0]["c_year"].ToString();
                lblWeb.Text = dt.Rows[0]["c_web"].ToString();
                lblEmail.Text = dt.Rows[0]["c_email"].ToString();
                lblContact.Text = dt.Rows[0]["c_contact"].ToString();
                lblRail.Text = dt.Rows[0]["c_rail"].ToString();
                lblRailKm.Text = dt.Rows[0]["c_rail_km"].ToString();
                lblBus.Text = dt.Rows[0]["c_bus"].ToString();
                lblBusKm.Text = dt.Rows[0]["c_bus_km"].ToString();
                lblAir.Text = dt.Rows[0]["c_air"].ToString();
                lblAirKm.Text = dt.Rows[0]["c_air_km"].ToString();

                int total = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    total += Convert.ToInt32(dt.Rows[i]["course_intake"]);
                }
                if (total > 0)
                {
                    rptCourse.DataSource = dt;
                    rptCourse.DataBind();
                    Label lblTotal = rptCourse.Controls[rptCourse.Controls.Count - 1].Controls[0].FindControl("lblTotal") as Label;
                    lblTotal.Text = "Total: " + total.ToString();
                }

                //for second college
                cmd = new SqlCommand("select c.*,area_name,cm.course_name,ccm.course_type,ccm.course_status,ccm.course_acdr,ccm.course_year,COALESCE(ccm.course_intake,0) as course_intake,CASE WHEN c.c_area = 1 THEN 'Urban' ELSE 'RURAL' end as c_area_type from college_course_master ccm right join college_master c on ccm.college_id = c.c_id inner join area_master a on c.c_area = a.area_id left join course_master cm on ccm.course_id = cm.course_id where c.c_id = @c2_id", con);
                cmd.Parameters.AddWithValue("@c2_id", c2_id);
                da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    lblName1.Text = dt.Rows[0]["c_name"].ToString();
                    lblRegion1.Text = dt.Rows[0]["area_name"].ToString();
                    lblType1.Text = dt.Rows[0]["c_area_type"].ToString();
                    lblAddress1.Text = dt.Rows[0]["c_address"].ToString();
                    lblDistrict1.Text = dt.Rows[0]["c_district"].ToString();
                    lblTaluka1.Text = dt.Rows[0]["c_taluka"].ToString();
                    lblPin1.Text = dt.Rows[0]["c_pincode"].ToString();
                    lblStd1.Text = dt.Rows[0]["c_std_code"].ToString();
                    lblYear1.Text = dt.Rows[0]["c_year"].ToString();
                    lblWeb1.Text = dt.Rows[0]["c_web"].ToString();
                    lblEmail1.Text = dt.Rows[0]["c_email"].ToString();
                    lblContact1.Text = dt.Rows[0]["c_contact"].ToString();
                    lblRail1.Text = dt.Rows[0]["c_rail"].ToString();
                    lblRailKm1.Text = dt.Rows[0]["c_rail_km"].ToString();
                    lblBus1.Text = dt.Rows[0]["c_bus"].ToString();
                    lblBusKm1.Text = dt.Rows[0]["c_bus_km"].ToString();
                    lblAir1.Text = dt.Rows[0]["c_air"].ToString();
                    lblAirKm1.Text = dt.Rows[0]["c_air_km"].ToString();

                    int total1 = 0;
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        total1 += Convert.ToInt32(dt.Rows[i]["course_intake"]);
                    }
                    if (total1 > 0)
                    {
                        rptCourse1.DataSource = dt;
                        rptCourse1.DataBind();
                        Label lblTotal = rptCourse1.Controls[rptCourse1.Controls.Count - 1].Controls[0].FindControl("lblTotal1") as Label;
                        lblTotal.Text = "Total: " + total1.ToString();
                    }
                }
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
}