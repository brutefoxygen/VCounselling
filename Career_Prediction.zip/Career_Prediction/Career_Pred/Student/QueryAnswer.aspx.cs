﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_QueryAnswer : System.Web.UI.Page
{
    string s_id ;
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    string q_id;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["s_id"] == null)
            Response.Redirect("../Login.aspx");

        s_id = Session["s_id"].ToString();

        q_id = Request.QueryString["id"].ToString();
        if (!IsPostBack) 
            fillRepeater(q_id);
    }

    private void fillRepeater(string q_id)
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select q.q_id,s.s_name,q_ques,qa_ans,qa_date from student_master s inner join query_answer_master qa on s.s_id = qa.s_id inner join query_master q on q.q_id = qa.q_id where q.q_id = @q_id", con);
            cmd.Parameters.AddWithValue("@q_id", Convert.ToInt32(q_id));
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                rptAns.DataSource = dt;
                rptAns.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void btnAns_Click(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(constr);
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd = new SqlCommand("insert into query_answer_master values (@s_id,@q_id,@ans,@date)", con);
            cmd.Parameters.AddWithValue("@s_id", Convert.ToInt32(s_id));
            cmd.Parameters.AddWithValue("@q_id", Convert.ToInt32(q_id));
            cmd.Parameters.AddWithValue("@ans", txtAns.Text.ToString());
            cmd.Parameters.AddWithValue("@date", DateTime.Now);
            int result = cmd.ExecuteNonQuery();
            if (result == 1){
                txtAns.Text = "";
                fillRepeater(q_id);
            }
            else
                Response.Write("<script>alert('Something went wrong')</script>");
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
}