﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_CollegeList : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    string c_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["s_id"] == null)
            Response.Redirect("../Login.aspx");


        if (!IsPostBack)
            fillDropDown();
    }

    private void fillDropDown()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from area_master", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                ddArea.DataTextField = "area_name";
                ddArea.DataValueField = "area_id";
                ddArea.DataSource = dt;
                ddArea.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void ddArea_SelectedIndexChanged(object sender, EventArgs e)
    {
        int area_id = Convert.ToInt32(ddArea.SelectedValue);
        getCollegeList(area_id);
    }

    private void getCollegeList(int area_id)
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select c_id,c_name from college_master where c_area=@id", con);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(area_id));
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if(dt.Rows.Count > 0)
            {
                rptCollege.DataSource = dt;
                rptCollege.DataBind();
                if(dt.Rows.Count > 2)
                    btn.Visible = true;
            }
            else
            {
                rptCollege.DataSource = null;
                rptCollege.DataBind();
                btn.Visible = false;
            }

        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
    protected void rptCollege_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        int c_id = Convert.ToInt32(e.CommandArgument);
        Response.Redirect("CollegeDetails.aspx?id=" + c_id);
    }
    protected void btn_Click(object sender, EventArgs e)
    {
        bool flag = false;
        int count = 0;
        string[] ids = new string[3];
        foreach (RepeaterItem item in rptCollege.Items)
        {
            CheckBox c = item.FindControl("chk") as CheckBox;
            if (c.Checked)
            {
                Label lblId = (Label)item.FindControl("lblId");
                c_id += lblId.Text + ",";
                ids = c_id.Split(',');
                count++;
            }
        }

        if (count == 2)
            Response.Redirect("CompareCollege.aspx?c1_id=" + ids[0] + "&c2_id=" + ids[1]);
        else
            Response.Write("<script>alert('Please select two colleges')</script>");

        //if (ids.Length != 3)
        //{
        //    Response.Write("<script>alert('Please select two colleges')</script>");
        //}
        //else
        //{
        //    Response.Redirect("CompareCollege.aspx?c1_id=" + ids[0] + "&c2_id=" + ids[1]);
        //}

    }
}