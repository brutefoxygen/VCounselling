﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_AskQuestion : System.Web.UI.Page
{

    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    string s_id ;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["s_id"] == null)
            Response.Redirect("../Login.aspx");

        s_id = Session["s_id"].ToString();
    }
    protected void btnAsk_Click(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(constr);
            if (con.State != ConnectionState.Open)
                con.Open();
            cmd = new SqlCommand("insert into query_master values (@s_id,@ques,@date)", con);
            cmd.Parameters.AddWithValue("@s_id", Convert.ToInt32(s_id));
            cmd.Parameters.AddWithValue("@ques", txtQuest.Text.ToString());
            cmd.Parameters.AddWithValue("@date", DateTime.Now);
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
                Response.Redirect("Home.aspx");
            else
                Response.Write("<script>alert('Something went wrong')</script>");
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
}