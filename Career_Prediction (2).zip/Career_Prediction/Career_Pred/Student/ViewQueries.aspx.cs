﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_ViewQueries : System.Web.UI.Page
{
    string s_id ="1";
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["s_id"] == null)
            Response.Redirect("../Login.aspx");


        if (!IsPostBack)
            fetchQueries();
    }

    private void fetchQueries()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select q.q_id,s.s_name,q_ques,q_date from student_master s inner join query_master q on s.s_id = q.s_id", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if(dt.Rows.Count > 0)
            {
                dlQry.DataSource = dt;
                dlQry.DataBind();
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
    protected void btnAnswer_Click(object sender, EventArgs e)
    {

    }
    protected void dlQry_ItemCommand(object source, DataListCommandEventArgs e)
    {
        int q_id = Convert.ToInt32(e.CommandArgument);
        Response.Redirect("QueryAnswer.aspx?id=" + q_id.ToString());
    }
}