﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_Predict : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    string s_id;
    string c_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["s_id"] == null)
            Response.Redirect("../Login.aspx");
    }
    protected void btnPred_Click(object sender, EventArgs e)
    {
        try
        {

            int exam = Convert.ToInt32(rbExam.SelectedValue);
            int type = Convert.ToInt32(rbRes.SelectedValue);

            con = new SqlConnection(constr);
            cmd = new SqlCommand("sp_predict",con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@exam", exam);
            cmd.Parameters.AddWithValue("@type", type);
            cmd.Parameters.AddWithValue("@marks", Convert.ToInt32(txtMarks.Text));
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if(dt.Rows.Count > 0)
            {
                rptCollege.DataSource = dt;
                rptCollege.DataBind();
            }
            else
            {
                rptCollege.DataSource = null;
                rptCollege.DataBind();
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
    protected void rptCollege_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        int c_id = Convert.ToInt32(e.CommandArgument);
        Response.Redirect("CollegeDetails.aspx?id=" + c_id);
    }
    protected void btn_Click(object sender, EventArgs e)
    {
        if (rptCollege.Items.Count > 0)
        {
            foreach (RepeaterItem item in rptCollege.Items)
            {
                CheckBox c = item.FindControl("chk") as CheckBox;
                if (c.Checked)
                {
                    Label lblId = (Label)item.FindControl("lblId");
                    c_id += lblId.Text + ",";
                }
            }

            string[] ids = c_id.Split(',');
            if (ids.Length != 3)
            {
                Response.Write("<script>alert('Please select two colleges')</script>");
            }
            else
            {
                Response.Redirect("CompareCollege.aspx?c1_id=" + ids[0] + "&c2_id=" + ids[1]);
            }
        }
    }
}