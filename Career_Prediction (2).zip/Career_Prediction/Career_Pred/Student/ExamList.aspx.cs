﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_ExamList : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["s_id"] == null)
            Response.Redirect("../Login.aspx");

        if (!IsPostBack)
            fillRepeater();
    }

    private void fillRepeater()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from exam_master", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                rptExam.DataSource = dt;
                rptExam.DataBind();
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
}