﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_QuizHome : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    string operation, c_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["s_id"] == null)
            Response.Redirect("../Login.aspx");

        if (!IsPostBack)
            fillDataList();
    }

    private void fillDataList()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from course_master", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if(dt.Rows.Count > 0)
            {
                dlCourse.DataSource = dt;
                dlCourse.DataBind();
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
    protected void dlCourse_ItemCommand(object source, DataListCommandEventArgs e)
    {
        int index = Convert.ToInt32(e.CommandArgument);

        Response.Redirect("Quiz.aspx?id="+index);
    }
}