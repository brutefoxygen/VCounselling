﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddExam : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    string operation, e_id;
    string fileName, filePath;

    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(constr);
        operation = Request.QueryString["action"].ToString();
        if (operation.Trim() == "edit")
        {
            e_id = Request.QueryString["id"].ToString();
            if(!IsPostBack)
                getExamDetails(e_id);
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {

        con = new SqlConnection(constr);
        if (con.State != ConnectionState.Open)
            con.Open();
       
        if (FileUpload1.HasFile && operation == "add")
        {
            fileName = Path.GetFileName(FileUpload1.FileName);
            FileUpload1.SaveAs(Server.MapPath("../Exam_Doc/") + fileName);
            filePath = "/Exam_Doc/" + fileName;
            cmd = new SqlCommand("insert into exam_master values (@name,@desc,@path)", con);
            cmd.Parameters.AddWithValue("@path", filePath);

        }
        else if (FileUpload1.HasFile && operation == "edit")
        {
            fileName = Path.GetFileName(FileUpload1.FileName);
            FileUpload1.SaveAs(Server.MapPath("../Exam_Doc/") + fileName);
            filePath = "/Exam_Doc/" + fileName;
            cmd = new SqlCommand("update exam_master set e_name=@name,e_desc=@desc,e_path=@path where e_id=@id", con);
            cmd.Parameters.AddWithValue("@path", filePath);
        }
        else if (!FileUpload1.HasFile && operation == "edit")
        {
            cmd = new SqlCommand("update exam_master set e_name=@name,e_desc=@desc where e_id=@id", con);
        }
        else
            Response.Write("<script>alert('Please select file')</script>");

        cmd.Parameters.AddWithValue("@id", Convert.ToInt32(e_id));
        
        cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
        cmd.Parameters.AddWithValue("@desc", txtDesc.Text.Trim());
        int result = cmd.ExecuteNonQuery();
        if (result == 1)
            Response.Redirect("ViewExam.aspx");
        else
            Response.Write("<script>alert('Something went wrong')</script>");
         

    }


    private void getExamDetails(string e_id)
    {
        try
        {
            cmd = new SqlCommand("select * from exam_master where e_id=@id", con);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(e_id));
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if(dt.Rows.Count > 0)
            {
                txtName.Text = dt.Rows[0]["e_name"].ToString();
                txtDesc.Text = dt.Rows[0]["e_desc"].ToString();
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
}