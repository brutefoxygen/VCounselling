﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_ViewQues : System.Web.UI.Page
{

    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillGridView();
        }
    }

    void fillGridView()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from question_master", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                gvStudent.DataSource = dt;
                gvStudent.DataBind();
            }
            else
            {
                gvStudent.DataSource = null;
                gvStudent.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void gvStudent_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int q_id = Convert.ToInt32(e.CommandArgument.ToString());

        string command = e.CommandName.ToString();
        if (command == "deleteTable")
            delete(q_id);

    }

    void delete(int q_id)
    {
        try
        {
            con = new SqlConnection(constr);
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd = new SqlCommand("delete from question_master where q_id=@id", con);
            cmd.Parameters.AddWithValue("@id", q_id);
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
                fillGridView();
            else
                Response.Write("<script>alert('Something went wrong')</script>");
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

}