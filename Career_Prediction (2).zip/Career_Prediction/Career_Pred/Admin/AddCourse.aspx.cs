﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddCourse : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    string operation, c_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["uname"] == null)
        //    Response.Redirect("../Login.aspx");

        try
        {
            con = new SqlConnection(constr);
            operation = Request.QueryString["action"].ToString();
            if (operation.Trim() == "edit")
                c_id = Request.QueryString["id"].ToString();

            if (!IsPostBack)
            {
                if (operation.Trim() == "edit")
                {
                    btnAdd.Text = "Edit";
                    cmd = new SqlCommand("select * from course_master where course_id=@id", con);
                    cmd.Parameters.AddWithValue("@id", Convert.ToInt32(c_id));
                    da = new SqlDataAdapter(cmd);
                    dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        txtName.Text = dt.Rows[0]["course_name"].ToString();
     
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            string fileName, filePath = "";
            con = new SqlConnection(constr);
            if (con.State != ConnectionState.Open)
                con.Open();
            if (FileUpload1.HasFile)
            {
                fileName = Path.GetFileName(FileUpload1.FileName);
                FileUpload1.SaveAs(Server.MapPath("../Course_Images/") + fileName);
                filePath = "/Course_Images/" + fileName;


                if (operation.Trim() == "add")
                    cmd = new SqlCommand("insert into course_master values (@name,@img)", con);
                else if (operation.Trim() == "edit")
                    cmd = new SqlCommand("update course_master set course_name=@name,course_img=@img where course_id=@id", con);
            }
            else if (operation.Trim() == "edit" && !FileUpload1.HasFile)
                cmd = new SqlCommand("update course_master set course_name=@name where course_id=@id", con);

            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(c_id));
            cmd.Parameters.AddWithValue("@name", txtName.Text.ToString().Trim());
            cmd.Parameters.AddWithValue("@img", filePath);
           

            int result = (int)cmd.ExecuteNonQuery();
            if (result == 1)
                Response.Redirect("ManageCourse.aspx");
            else
                Response.Write("<script>alert('Something went wrong')</script>");
            con.Close();

        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
}