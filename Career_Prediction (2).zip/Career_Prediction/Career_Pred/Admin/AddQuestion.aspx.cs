﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddQuestion : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillDropDown();
        }
    }

    private void fillDropDown()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from course_master", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                ddCourse.DataTextField = "course_name";
                ddCourse.DataValueField = "course_id";
                ddCourse.DataSource = dt;
                ddCourse.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        int c_id = Convert.ToInt32(ddCourse.SelectedItem.Value);

        string ques = txtQues.Text.ToString();
        string op1 = opt1.Text.ToString();
        string op2 = opt2.Text.ToString();
        string op3 = opt3.Text.ToString();
        string op4 = opt4.Text.ToString();
        string ans = txtAns.Text.ToString();

        if (ans != op1 && ans != op2 && ans != op3 && ans != op4)
            Response.Write("<script>alert('Answer doesnot match any of above options')</script>");
        else if (op1.Equals(op2) || op1.Equals(op3) || op1.Equals(op4) || op2.Equals(op3) || op2.Equals(op4)
            || op3.Equals(op4))
            Response.Write("<script>alert('One or more options have same values')</script>");
        else
        {
            try
            {
                con = new SqlConnection(constr);
                if (con.State != ConnectionState.Open)
                    con.Open();

                cmd = new SqlCommand("insert into question_master values(@cid,@ques,@op1,@op2,@op3,@op4,@ans)", con);
                cmd.Parameters.AddWithValue("@cid", c_id);
                cmd.Parameters.AddWithValue("@ques", ques);
                cmd.Parameters.AddWithValue("@op1", op1);
                cmd.Parameters.AddWithValue("@op2", op2);
                cmd.Parameters.AddWithValue("@op3", op3);
                cmd.Parameters.AddWithValue("@op4", op4);
                cmd.Parameters.AddWithValue("@ans", ans);
                int result = cmd.ExecuteNonQuery();
                if (result == 1)
                {
                    Response.Redirect("ViewQues.aspx");
                }
                else
                    Response.Write("<script>alert('Something went wrong')</script>");

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}