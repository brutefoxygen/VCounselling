﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddCollege_Course : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt;
    string constr = ConfigurationManager.ConnectionStrings["connect"].ToString();
    string operation, cc_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            fillCollegeDropdown();
        
        operation = Request.QueryString["action"].ToString();
        if (operation.Trim() == "edit")
        {
            btnAdd.Text = "Edit";
            cc_id = Request.QueryString["id"].ToString();
            if (!IsPostBack)
                getDetails(cc_id);
        }         
    }

    private void getDetails(string cc_id)
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from college_course_master where cc_id=@cc_id", con);
            cmd.Parameters.AddWithValue("@cc_id", Convert.ToInt32(cc_id));
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if(dt.Rows.Count > 0)
            {
                ddCollege.SelectedValue = dt.Rows[0]["college_id"].ToString();
                ddType.Text = dt.Rows[0]["course_type"].ToString();
                ddStatus.Text = dt.Rows[0]["course_status"].ToString();
                txtAcdr.Text = dt.Rows[0]["course_acdr"].ToString();
                txtYear.Text = dt.Rows[0]["course_year"].ToString();
                txtIntake.Text = dt.Rows[0]["course_intake"].ToString();
                ddCollege.Enabled = false;
                ddCourse.Enabled = false;
            }
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }


    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(constr);
            if (con.State != ConnectionState.Open)
                con.Open();

            if (operation.Trim() != "edit")
                cmd = new SqlCommand("insert into college_course_master values (@college_id,@course_id,@course_type,@course_status,@course_acdr,@course_year,@course_intake)", con);     
            else
                cmd = new SqlCommand("update college_course_master set course_type=@course_type,course_status=@course_status,course_acdr=@course_acdr,course_year=@course_year,course_intake=@course_intake", con);
            
                
            cmd.Parameters.AddWithValue("@college_id", ddCollege.SelectedValue);
            cmd.Parameters.AddWithValue("@course_id", ddCourse.SelectedValue);
            cmd.Parameters.AddWithValue("@course_type", ddType.Text.ToString().Trim());
            cmd.Parameters.AddWithValue("@course_status", ddStatus.Text.ToString().Trim());
            cmd.Parameters.AddWithValue("@course_acdr", txtAcdr.Text.ToString().Trim());
            cmd.Parameters.AddWithValue("@course_year", Convert.ToInt32(txtYear.Text.ToString().Trim()));
            cmd.Parameters.AddWithValue("@course_intake", Convert.ToInt32(txtIntake.Text.ToString().Trim()));
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
                Response.Redirect("ViewCollege_Course.aspx");
            else
                Response.Write("<script>alert('Something went wrong')</script>");
        }
        catch(Exception ex)
        {
            throw ex;
        }

    }
    private void fillCollegeDropdown()
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select c_id,c_name from college_master", con);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                ddCollege.DataTextField = "c_name";
                ddCollege.DataValueField = "c_id";
                ddCollege.DataSource = dt;
                ddCollege.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void ddCollege_SelectedIndexChanged(object sender, EventArgs e)
    {
        int college_id = Convert.ToInt32(ddCollege.SelectedValue);
        fillCourseDropdown(college_id);
    }

    private void fillCourseDropdown(int college_id)
    {
        try
        {
            con = new SqlConnection(constr);
            cmd = new SqlCommand("select * from course_master where course_id NOT IN (select course_id from college_course_master where college_id = @c_id)", con);
            cmd.Parameters.AddWithValue("@c_id", college_id);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                ddCourse.DataTextField = "course_name";
                ddCourse.DataValueField = "course_id";
                ddCourse.DataSource = dt;
                ddCourse.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

}